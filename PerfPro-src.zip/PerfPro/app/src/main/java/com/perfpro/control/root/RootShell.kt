package com.perfpro.control.root

import com.topjohnwu.superuser.Shell
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object RootShell {
    suspend fun isRoot(): Boolean = withContext(Dispatchers.IO) {
        try { Shell.getShell().isRoot } catch (_: Exception) { false }
    }
    suspend fun exec(cmd: String): String = withContext(Dispatchers.IO) {
        Shell.cmd(cmd).exec().out.joinToString("\n")
    }
    suspend fun execOk(cmd: String): Boolean = withContext(Dispatchers.IO) {
        Shell.cmd(cmd).exec().isSuccess
    }
    suspend fun readFile(path: String): String = withContext(Dispatchers.IO) {
        Shell.cmd("cat $path 2>/dev/null").exec().out.firstOrNull()?.trim() ?: ""
    }
    suspend fun writeFile(path: String, value: String): Boolean = withContext(Dispatchers.IO) {
        Shell.cmd("echo '$value' > $path 2>/dev/null").exec().isSuccess
    }
    suspend fun chmod(path: String, mode: String): Boolean = withContext(Dispatchers.IO) {
        Shell.cmd("chmod $mode $path 2>/dev/null").exec().isSuccess
    }
}
